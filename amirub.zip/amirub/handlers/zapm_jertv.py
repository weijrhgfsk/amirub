from config import f_config, victims_exclusion, victims_file, \
    Me, trusted_f, black_iris, user_config_js, Style
from storage.storage import Settings, me_inf, my_illnesses, JsRead, ctimer, cycle_timers, VictimsEclusionRead
from functions import func
from loader import app

from pyrogram import Client, filters, enums
from pyrogram.types import Message
from pyrogram.errors import RandomIdDuplicate
from datetime import datetime

import asyncio, re, random, json

@app.on_message(filters.text, group = 3)
async def zapominalka_jertv(app: Client, msg: Message):
    
    msgt = msg.text
    msgtl = msg.text.lower()
    entity = str(msg.chat.id)
    
    if msg.reply_to_message:
        msgr = msg.reply_to_message
        if not msg.reply_to_message.service:
            if (not msgr or not msgr.text): return
            msgrt = msgr.text
            msgrtl = msgrt.lower()
    
    if msg.from_user and str(msg.from_user.id) in Settings.trusted:
        
        # опл
        if msgtl == f'{Settings.name} зарлист бэкап' or msgtl == '.зарлист бэкап' and msg.from_user.id == Me.me.id:
            today = datetime.utcnow()
            time = datetime.strftime(today, '%d.%m.%Y & %H:%M:%S')
            
            if Settings.zar_backuper:
                time_dif = today - Settings.zar_backuper
                if int(time_dif.total_seconds()) < 60*60:
                    delay = round((60*60 - time_dif.total_seconds()) / 60)
                    Settings.zar_backuper = today
                    text = f'You can only backup zarlist once per hour, the next backup will be available in {delay} minutes'
                    temp = await msg.reply(text)
                    asyncio.create_task(func.delete_msg([msg, temp], delay = 16))
                    return
            Settings.zar_backuper = today
            
            if Settings.sex == 'он':
                sex = 'mister'
            else:
                sex = 'missis'
            mesg = f'<i>> Your zarlist <b>{sex} {func.up_first_word(Settings.name)}</b> {time}</i>'
            await app.send_document(entity, victims_file, caption=mesg)
        
        # +оп @link
        if re.fullmatch(r'\+(|{})(о|оп) @[\w\d\S]+ (\d|\d\d|\d\d\d|\d\d\d\d|\d+(k|к)|\d+\.\d(k|к))'.format(re.escape(Settings.prefix)), msgtl):
            if re.fullmatch(r'\+(о|оп)', msgtl.split(' ')[0]) and msg.from_user.id != Me.me.id:
                return
            if me_inf.immunity is None:
                temp = await msg.reply('To save victims, you need to show your lab, it can be shown in the ls of iris or anywhere else')
                await func.delete_msg([temp, msg], 24)
                return
            
            db_check = await func.check_in_db(app, msgtl, JsRead, victims_file, get_entity=True, iris_id = black_iris)
            if db_check['instance']:
                zar = db_check['instance']
                id = list(zar)[0]
            else:
                temp = await msg.reply('User not found')
                asyncio.create_task(func.delete_msg([msg, temp], delay = 8))
                return
            if 'username' in zar[id]:
                username = zar[id]['username']
            else:
                username = None
            name = zar[id]['name']
            
            exp = msgt.split(' ')[2].replace('к','k')
            ot_data = me_inf.zar_date
            victims_db = {}
            
            if 'experience' in zar[id]:
                exp_do = f'<s><b>+{zar[id]["experience"]}</b></s> '
            else:
                exp_do = ''
            
            if id in VictimsEclusionRead.js_read:
                exclusion = f'<i>In ex, remove</i> <code>-{Settings.prefix}иск @{id}</code>'
            else:
                exclusion = f'<i>Add to ex.</i> <code>+{Settings.prefix}иск @{id}</code>'
            
            name = func.less_name(name)
            bio_entity = f'<a href="tg://openmessage?user_id={id}">{name}</a>'
            emoji1 = (Style.prem_nom_writing if Me.me.is_premium else Style.bio_resource)
            
            text = (
                f'{emoji1} <i><b>{bio_entity}</b></i> {exp_do}+{exp} 🧬</b> <i>to</i> <b>{ot_data}</b>\n'
                f'<code>Заразить @{id}</code>'
            )
            
            temp = await msg.reply(text)
            
            victims_db[id] = {
                'experience': exp,
                'ot_data': ot_data,
                'name': name
            }
            if username:
                victims_db[id]['username'] = username
            
            func.json_append(victims_db, victims_file)
            JsRead.reload(refresh=True)
            
            asyncio.create_task(func.delete_msg([msg, temp], delay = 16))
        
        # -оп @id
        if re.fullmatch(r'-(|{})(о|оп) @[\w\d\S]+'.format(re.escape(Settings.prefix)), msgtl):
            if re.fullmatch(r'-(о|оп)', msgtl.split(' ')[0]) and msg.from_user.id != Me.me.id:
                return
            link = func.tag_get(msgtl)
            emoji1 = (Style.prem_redis_think if Me.me.is_premium else Style.grey_question)
            emoji2 = (Style.prem_duck_cleaning if Me.me.is_premium else Style.page_with_curl)
            db_check = await func.check_in_db(app, link, JsRead, victims_file, bot_getid=False, iris_id = black_iris)
            if db_check['instance'] is False:
                text = f'{emoji1} @{link} does not exist'
            else:
                id = list(db_check['instance'])[0]
                if db_check['zar'] == 'True':
                    name = (db_check['instance'][id]['name'] if db_check['instance'][id].get('name') else id)
                    bio_entity = f'<a href="tg://openmessage?user_id={id}">{name}</a>'
                    func.json_del(victims_file, id)
                    JsRead.reload(refresh=True)
                    
                    text = f'{emoji2} {bio_entity} removed from mentality'
                else:
                    name = ''
                    async for msg_ in app.search_global(f'🆔 пользователя равен @{id}'):
                        if msg_.entities:
                            name = re.split('🆔 пользователя | равен', msg_.text)[1]
                    name = (f'<a href="tg://openmessage?user_id={id}">{name}</a>' if name != '' else f'<a href="tg://openmessage?user_id={id}">{id}</a>')
                    text = f"{emoji1} {name} can't find in zarist"
            temp = await msg.reply(text)
            asyncio.create_task(func.delete_msg([msg, temp], delay = 8))
        
        # добавить жертву/list в исключения
        if msgtl.split(' ')[0] == f'+{Settings.prefix}иск' and func.msg_check_tattack(msgt) or msgtl.split(' ')[0] == '+иск' and func.msg_check_tattack(msgt) and msg.from_user.id == Me.me.id \
        or msg.reply_to_message and msgtl == f'+{Settings.prefix}иск' or msg.reply_to_message and msgtl == '+иск' and msg.from_user.id == Me.me.id:
            # добавить лист в исключения
            if msg.reply_to_message and msgtl == f'+{Settings.prefix}иск' or msg.reply_to_message and msgtl == '+иск' and msg.from_user.id == Me.me.id:
                msgr = msg.reply_to_message
                user_added = []
                user_not_added = []
                user_not_found = []
                for line in msgr.text.html.splitlines():
                  tag = re.search(r'(@[\d\w]+|\?user_id=\d+|t\.me/[\w\d]+)', line)
                  if tag:
                    link = tag[0].replace('?user_id=', '').replace('@', '').replace('t.me/', '')
                    db_check = await func.check_in_db(app, link, JsRead, victims_file, exclusion=VictimsEclusionRead.js_read, iris_id = black_iris)
                    if db_check['not_found'] == 'True':
                        user_not_found.append(f'❔ {link}')
                        continue
                    zar = db_check['instance']
                    id = list(zar)[0]
                    name = zar[id]['name']
                    name = func.less_name(name)
                    bio_entity = f'<a href="tg://openmessage?user_id={id}">{name}</a>'
                    if id not in VictimsEclusionRead.js_read:
                        user_added.append(f'💌 {bio_entity}\n')
                        func.victims_exclusion_append({id: {'name': name}}, victims_exclusion)
                    else:
                        user_not_added.append(f'📃 {bio_entity}\n')
                    if 'username' in zar[id]:
                        JsRead.js_read = func.zarlist_automation(id, name, victims_file, zar[id]['username'])
                    else:
                        JsRead.js_read = func.zarlist_automation(id, name, victims_file)
                    VictimsEclusionRead.refresh()
                    JsRead.reload(refresh=True)
                mesg = (
                    '<b>Victimer added to exclusions:</b>\n'
                    f'{"".join(user_added)}\n'
                    '<b>Already present victims in exclusions:</b>\n'
                    f'{"".join(user_not_added)}\n'
                    '<b>Non-existent victims</b>\n'
                    f'{"".join(user_not_found)}\n'
                )
                temp = await msg.reply(mesg)
                asyncio.create_task(func.delete_msg([msg, temp], delay = 60))
            # добавить жертву в исключения
            elif msgtl.split(' ')[0] == f'+{Settings.prefix}иск' and func.msg_check_tattack(msgt) or msgtl.split(' ')[0] == '+иск' and func.msg_check_tattack(msgt) and msg.from_user.id == Me.me.id:
                link = func.tag_get(msgtl)
                db_check = await func.check_in_db(app, link, JsRead, victims_file, exclusion=VictimsEclusionRead.js_read, iris_id = black_iris)
                if db_check['not_found'] == 'True':
                    temp = await msg.reply(f'❔ Жертва @{link} не существует')
                    asyncio.create_task(func.delete_msg([msg, temp], delay = 8))
                    return
                zar = db_check['instance']
                id = list(zar)[0]
                name = zar[id]['name']
                name = func.less_name(name)
                bio_entity = f'<a href="tg://openmessage?user_id={id}">{name}</a>'
                emoji1 = (Style.prem_redis_think if Me.me.is_premium else Style.grey_question)
                emoji2 = (Style.prem_nom_writing if Me.me.is_premium else Style.pencil)
                
                if id not in VictimsEclusionRead.js_read:
                    text = (
                        f'<i>{emoji2} {bio_entity} added to exclusions</i>\n'
                        f'<code>-{Settings.prefix}иск @{id}</code>'
                    )
                    func.victims_exclusion_append({id: {'name': name}}, victims_exclusion)
                else:
                    text = (
                        f'<i>{emoji1} {bio_entity} already in exclusions</i>\n'
                        f'<code>-{Settings.prefix}иск @{id}</code>'
                    )
                
                if 'username' in zar[id]:
                    JsRead.js_read = func.zarlist_automation(id, name, victims_file, zar[id]['username'])
                else:
                    JsRead.js_read = func.zarlist_automation(id, name, victims_file)
                VictimsEclusionRead.refresh()
                JsRead.reload(refresh=True)
                
                temp = await msg.reply(text)
                asyncio.create_task(func.delete_msg([msg, temp], delay = 16))
        
        # убрать жертву/list из исключений
        elif msgtl.split(' ')[0] == f'-{Settings.prefix}иск' and func.msg_check_tattack(msgt) or msgtl.split(' ')[0] == '-иск' and func.msg_check_tattack(msgt) and msg.from_user.id == Me.me.id \
        or msg.reply_to_message and msgtl == f'-{Settings.prefix}иск' or msg.reply_to_message and msgtl == '-иск' and msg.from_user.id == Me.me.id:
            # убрать лист из исключений
            if msg.reply_to_message and msgtl == f'-{Settings.prefix}иск' or msg.reply_to_message and msgtl == '-иск' and msg.from_user.id == Me.me.id:
                msgr = msg.reply_to_message
                user_removed = []
                user_not_removed = []
                user_not_found = []
                for line in msgr.text.html.splitlines():
                  tag = re.search(r'(@[\d\w]+|\?user_id=\d+|t\.me/[\w\d]+)', line)
                  if tag:
                    link = tag[0].replace('?user_id=', '').replace('@', '').replace('t.me/', '')
                    db_check = await func.check_in_db(app, link, JsRead, victims_file, exclusion=VictimsEclusionRead.js_read, iris_id = black_iris)
                    if db_check['not_found'] == 'True':
                        user_not_found.append(f'❔ {link}')
                        continue
                    zar = db_check['instance']
                    id = list(zar)[0]
                    name = zar[id]['name']
                    name = func.less_name(name)
                    bio_entity = f'<a href="tg://openmessage?user_id={id}">{name}</a>'
                    if id in VictimsEclusionRead.js_read:
                        user_removed.append(f'📝 {bio_entity}\n')
                        with open(victims_exclusion, 'r', encoding='utf-8') as f:
                            read = json.load(f)
                        read.pop(id)
                        with open(victims_exclusion, 'w', encoding='utf-8') as f:
                            json.dump(read, f, indent=4)
                    else:
                        user_not_removed.append(f'📃 {bio_entity}\n')
                    if 'username' in zar[id]:
                        JsRead.js_read = func.zarlist_automation(id, name, victims_file, zar[id]['username'])
                    else:
                        JsRead.js_read = func.zarlist_automation(id, name, victims_file)
                    VictimsEclusionRead.refresh()
                    JsRead.reload(refresh=True)
                mesg = (
                    '<b>Victims removed from exclusions:</b>\n'
                    f'{"".join(user_removed)}\n'
                    '<b>Victims non-existent in exclusions:</b>\n'
                    f'{"".join(user_not_removed)}\n'
                    '<b>Non-existent victims</b>\n'
                    f'{"".join(user_not_found)}\n'
                )
                temp = await msg.reply(mesg)
                asyncio.create_task(func.delete_msg([msg, temp], delay = 60))
            
            # убрать жертву из исключений
            elif msgtl.split(' ')[0] == f'-{Settings.prefix}иск' and func.msg_check_tattack(msgt) or msgtl.split(' ')[0] == '-иск' and func.msg_check_tattack(msgt) and msg.from_user.id == Me.me.id:
                link = func.tag_get(msgtl)
                emoji1 = (Style.prem_redis_think if Me.me.is_premium else Style.grey_question)
                emoji2 = (Style.prem_duck_cleaning if Me.me.is_premium else Style.page_with_curl)
                db_check = await func.check_in_db(app, link, JsRead, victims_file, exclusion=VictimsEclusionRead.js_read, iris_id = black_iris)
                if db_check['not_found'] == 'True':
                    text = f'{emoji1} @{link} does not exist'
                    temp = await msg.reply(text)
                    asyncio.create_task(func.delete_msg([msg, temp], delay = 8))
                    return
                zar = db_check['instance']
                id = list(zar)[0]
                name = zar[id]['name']
                name = func.less_name(name)
                bio_entity = f'<a href="tg://openmessage?user_id={id}">{name}</a>'
                if id in VictimsEclusionRead.js_read:
                    temp = await msg.reply(f'<i>{emoji2} <b><i>{bio_entity}</b></i> removed from exclusions </i>\n<code>+{Settings.prefix}иск @{id}</code>')
                    with open(victims_exclusion, 'r', encoding='utf-8') as f:
                        read = json.load(f)
                    read.pop(id)
                    with open(victims_exclusion, 'w', encoding='utf-8') as f:
                        json.dump(read, f, indent=4)
                else:
                    temp = await msg.reply(f'<i>{emoji1} <b><i>{bio_entity}</b></i> not found in exclusions </i>\n<code>+{Settings.prefix}иск @{id}</code>')
                if 'username' in zar[id]:
                    JsRead.js_read = func.zarlist_automation(id, name, victims_file, zar[id]['username'])
                else:
                    JsRead.js_read = func.zarlist_automation(id, name, victims_file)
                VictimsEclusionRead.refresh()
                JsRead.reload(refresh=True)
                asyncio.create_task(func.delete_msg([msg, temp], delay = 16))
        
        if re.fullmatch(r'!иск (авто|((\d+\.\d|\d+)(k|к)|[\d\s]+))', msgtl):
            if msgtl == '!иск авто':
                temp = await app.send_message(entity, '✉️ Автозапись жертв в исключения выключен')
                func.edit_cf(f_config, 'user_settings', 'auto_ex', 'False')
                Settings.refresh(f_config)
                asyncio.create_task(func.delete_msg([msg, temp], delay = 12))
            else:
                exp = msgtl.split(' ')[1].replace('к', 'k')
                temp = await app.send_message(entity, f'💌 Автозапись жертв в исключения включен с {exp} опыта')
                func.edit_cf(f_config, 'user_settings', 'auto_ex', exp)
                Settings.refresh(f_config)
                asyncio.create_task(func.delete_msg([msg, temp], delay = 16))
        
        # оп @id
        if (re.fullmatch(r'(((|\.){}|\.|)(оп|о))'.format(re.escape(Settings.prefix)), msgtl.split(' ')[0]) and (func.msg_check_tattack(msgtl) or not func.msg_check_tattack(msgtl) and msg.reply_to_message) and len(msg.text.splitlines()) == 1) and msgt[:3] != 'о з':
            temp, uid, which_reply_msg = None, None, None
            JsRead.reload()
            js_read = JsRead.js_read
            
            # чек reply-user
            if (msgtl == f'.{Settings.prefix}о' or msgtl == '.о') and msg.reply_to_message:
                uid = str(msgr.from_user.id)
            else:
                if msg.reply_to_message:
                    # Message service
                    if msgr.service:
                        uid = str(msgr.from_user.id)
                    # Служба безопасности
                    if msgr.entities and '🕵️‍♂️ Служба безопасности' in msgr.text:
                        which_reply_msg = msgr
                        if len(msgr.entities) >= 5:
                            uid = func.tag_get(msgr.entities[2].url)
                        else:
                            return
                    # reply text
                    elif func.msg_check_tattack(msgrtl):
                        uid = func.tag_get(msgr.text.lower())
                    # reply text ирис заражение
                    elif re.findall(r'🦠 .+ подвер[гла]+ заражению', msgrtl) and not '🕵️‍♂️ Служба безопасности' in msgrt and len(msgr.entities) == 2:
                        which_reply_msg = msgr
                        uid = str(msgr.entities[1].user.id)
                # text
                else:
                    if func.msg_check_tattack(msgtl):
                        uid = func.tag_get(msgtl)
            
            if uid is None:
                return
            
            if not uid.isdigit():
                uid_ = uid
                check = func.db_user_check(uid, js_read)
                if check is False:
                    uid = await func.check_in_db(app, uid, JsRead, victims_file, exclusion=VictimsEclusionRead.js_read, get_entity = True)
                    if uid['not_found'] == 'True':
                        temp = await msg.reply(f'<i>☠️ User not found <code>@{uid_}</code></i>')
                        asyncio.create_task(func.delete_msg([msg, temp], delay = 7))
                        return
                    else:
                        if not uid_.isdigit():
                            
                            id = list(uid['instance'])[0]
                            
                            if id in js_read:
                                victims_db = {id: {
                                    'experience': JsRead.js_read[id]['experience'],
                                    'ot_data': JsRead.js_read[id]['ot_data'],
                                    'username': uid_,
                                    'name': uid['instance'][id]['name']
                                }}
                                
                                func.json_append(victims_db, victims_file)
                                JsRead.reload(refresh=True)
                else:
                    uid = check
            
            if isinstance(uid, dict):
                uid = list(uid['instance'])[0]
            else:
                uid = str(uid)
            
            js_read = JsRead.js_read
            kd = f'<code>Заразить @{uid}</code>'
            exclusion_text = ''
            
            if VictimsEclusionRead.js_read.get(uid):
                exclusion_text = f'{Style.exclusion_on} /'
            
            if js_read.get(uid):
                exp = js_read[uid]["experience"]
                
                if js_read[uid].get('name'):
                    name = js_read[uid]['name']
                else:
                    name = (await func.get_uid_in_bot(app, uid, JsRead, victims_file, random_bool = False)).get('name')
                name = func.less_name(name)
                
                if js_read[uid].get('infect_time'):
                    infect_time = js_read[uid]['infect_time']
                    minute = round((datetime.strptime(infect_time, '%d.%m.%Y %H:%M:%S') - datetime.now()).total_seconds() / 60)
                    if minute >= 0:
                        kd = f'{Style.clock} <b>{minute}</b>м'
                
                bio_entity = f'<a href="tg://openmessage?user_id={uid}">{name}</a>'
                
                text = (
                    f'{exclusion_text} <i>{bio_entity}</i> <b>+{exp} 🧬</b>\n'
                    f'{kd}'
                )
            else:
                name = await func.name_searcher_by_id(app, uid)
                name = (f'<a href="tg://openmessage?user_id={uid}">{name}</a>' if name else f'<code>@{uid}</code>')
                
                text = (
                    f'{exclusion_text} <b><i>{name} new {Style.little_stars}</i></b>\n'
                    f'<code>Заразить @{uid}</code>'
                )
            
            try:
                if which_reply_msg is None:
                    temp = await msg.reply(text, quote = False)
                else:
                    temp = await which_reply_msg.reply(text)
            except RandomIdDuplicate:
                pass
            
            if temp:
                asyncio.create_task(func.delete_msg([msg, temp], delay = 20))



