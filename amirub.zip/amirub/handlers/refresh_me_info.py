from loader import app
from config import Me

from pyrogram import Client, filters
from pyrogram.types import Message

import asyncio

@app.on_message(filters.text & filters.user('me'), group = 100)
async def user_update(app: Client, msg: Message):
    if msg.from_user != Me.me:
        Me.me = msg.from_user

async def user_update_every_30_minute(app: Client):
    while True:
        await asyncio.sleep(60*30)
        me = await app.get_me()
        if me != Me.me:
            Me.me = me